# This program is to enter and calculate new insurance policy information  for One Stop Insurance Company customers. 
# It is written from  November 16, 2023 to November 28, 2023.
# By Benjamin Osemene.

# Required libraries
import datetime
import formatvalues as fv

# Program default values 
 
POLICY_NUM = 1944
BASIC_PREMIUM_RATE = 869.00
DISC_FOR_ADD_CARS = .25
EXTRA_LIABILITY_COVERAGE = 130.00
GLASS_COVERAGE = 86.00
LOANER_CAR_COVERAGE = 58.00
HST_RATE = .15
FEE_MONTHLY_PAYMENT = 39.99



# Program fuctions
def CalcInsPrem(NumCars,ExtraLiability, GlassCoverage, LoanerCar):
    # Calculate insurance premium

    if NumCars ==1:
        InsPrem = BASIC_PREMIUM_RATE # for first automobile car

    if NumCars > 1: # additional automobile offered a discount
        InsPrem = (NumCars - 1) * BASIC_PREMIUM_RATE * (1 - DISC_FOR_ADD_CARS)

    TotExtraCost = 0
    if ExtraLiability == "Y":
        TotExtraCost += NumCars * EXTRA_LIABILITY_COVERAGE
    if GlassCoverage == "Y": 
        TotExtraCost +=  NumCars * GLASS_COVERAGE
    if LoanerCar =="Y":
        TotExtraCost += NumCars * LOANER_CAR_COVERAGE

        TotInsPrem = InsPrem + TotExtraCost

        HSTCal =  TotInsPrem * HST_RATE

        TotalCost = TotInsPrem + HSTCal
        
    return InsPrem, TotExtraCost, TotInsPrem, HSTCal, TotalCost


def CalcMonthlyPayment(TotalCost, DownPayAmt):
    # Calculate monthly payment

    if PaymtMethod == "monthly":
        MonthlyPayment = (TotalCost + FEE_MONTHLY_PAYMENT)/8
    elif PaymtMethod == "down pay": 
        MonthlyPayment = (TotalCost - DownPayAmt + FEE_MONTHLY_PAYMENT)/8
    elif PaymtMethod == "full":
        MonthlyPayment = (TotalCost + FEE_MONTHLY_PAYMENT)/8

    return MonthlyPayment


def CalcFirstPaymtDate(PurchaseDate):
    # calculate the payment date as the first day of the next month.

    PurchaseYear = PurchaseDate.year
    PurchaseMonth = PurchaseDate.month
    PurchaseDay = PurchaseDate.day
    
    FirstPaymentDate = datetime.datetime (PurchaseYear,PurchaseMonth + 1, 1)

    return FirstPaymentDate
    
    
# The main program

while True:

# User inputs

    while True:
        CustFirstName = input("Enter the customer first name:     ").title()
        if CustFirstName =="":
            print("Customer first name must not be blank-please re-enter.")
        else:
            break


    while True:
        CustLastName = input("Enter the customer last name:     ").title()
        if CustLastName =="":
            print("Customer last name must not be blank-please re-enter.")
        else:
            break


    while True:
        CustAddress = input("Enter the customer address:     ")
        if CustAddress =="":
            print("Customer address must not be blank-please re-enter.")
        else:
            break


    while True:
        CustCity = input("Enter the customer city:     ").title()
        if CustCity =="":
            print("Customer city must not be blank-please re-enter.")
        else:
            break

    ProvList =["AB","BC", "MB","NB", "NL", "NS","ON","PE","QC","SK"]
    while True:
        CustProv = input("Enter the customer province(XX):     ").upper()
        if  CustProv == "":
            print("Error - province cannot be blank - please re-enter")
        elif len(CustProv)!=2:
            print("Error - province is a 2 digit code. please re-enter.")
        elif CustProv not in ProvList:
            print("Error - Not a valid province. Please re-enter")
        else:
            break
    print("Province has been successfully entered.")


    while True:
        CustPostcode = input("Enter the customer postal code(X#X#X#):     ").upper()
        if CustPostcode =="":
            print("Customer postal code must not be blank-please re-enter.")
        else:
            break


    while True:
        CustPhoneNum = input("Enter the customer phone number(9999999999):     ")
        if len(CustPhoneNum)!=10:
            print("Customer phone number must contain 10 digits - please re-enter.")
        elif CustPhoneNum =="":
            print("Phone number cannot be blank-please re-enter.")
        else:
            break


    while True:
        try:
            NumCars = int(input("Enter the number of cars insured:     "))
        except:
            print(" Number of cars insured is not valid number- please re-enter")
        else:
            break


    while True:
        ExtraLiability = input(" Do you want extra liability up to $1,000,000?(Y or N):     ").upper()
        if ExtraLiability =="":
            print("Extra Liability option cannot be blank - please enter Y or N ")
        else:
            break


    while True:
        GlassCoverage = input(" Do you want optional glass coverage?(Y or N):     ").upper()
        if GlassCoverage =="":
            print("Glass coverage option cannot be blank - please enter Y or N ")
        else:
            break


    while True:
        LoanerCar = input(" Do you want optional loaner car?(Y or N):     ").upper()
        if LoanerCar =="":
            print("Loaner car option cannot be blank - please enter Y or N ")
        else:
            break


    while True:
        PaymtMethod = input("Enter the payment method(full or monthly or down pay)):     ")
        PaymtMethods =["full", "monthly", "down pay"]
        if  PaymtMethod not in PaymtMethods:
            print("Invalid payment method - please re-enter.")
        else:
            break


    while True:
        try:
            DownPayAmt = float(input("Enter the amount of the down payment:     "))
        except:
            print("Payment method is not down pay - please re-enter")
        else:
            break


    
    while True:
        PrevClaimsDate = input("Enter the previous claim date (YYYY-MM-DD). Press enter to finish:     ")
        if PrevClaimsDate == "":
            print("Error- Invalid date. Please re-enter ")
        else:
            break


    
    while True:
        try:
            PrevClaimsCost = float(input("Enter the previous claim cost: Press enter to finish:     "))  
        except:
            print("Claim amount is not a valid number - please re-enter")
        else:
            break
    

    # Program calculations

    
    InsPrem,TotExtraCost, TotInsPrem, HSTCal, TotalCost = CalcInsPrem(NumCars,ExtraLiability, GlassCoverage, LoanerCar)

    MonthlyPayment = CalcMonthlyPayment(TotalCost, DownPayAmt)

    CurDate = datetime.datetime.now()
    # format current date as a string using strftime method 
    CurDateStr = CurDate.strftime("%Y-%m-%d")

    InvDate = CurDateStr

    PurchaseDate = "2023-11-16"
    # converting string to datetime value.
    PurchaseDate = datetime.datetime.strptime(PurchaseDate, "%Y-%m-%d")
    FirstPaymentDate = CalcFirstPaymtDate(PurchaseDate)

    # Program output

    print()
    print()
    # Displayed program inputs and calculated values.
    print(f"ONE STOP INSURANCE             {InvDate:<10s}")
    print(f"CUSTOMER POLICY NUMBER              1944")
    print(f"----------------------------------------")

    print(f"Customer:")

    print(f"{CustFirstName:<9s}")
    print(f"{CustLastName:<9s}")
    print(f"{CustAddress:<20s} {CustCity}, {CustProv} {CustPostcode}")
    print(f"{CustPhoneNum:<13s}")

    print(f"Number of cars insured:    {NumCars:>2}")


    print(f"Insurance Premium:            {fv.FDollar2(InsPrem):>10s}")
    print(f"Total Extra Costs:            {fv.FDollar2(TotExtraCost):>10s}")
    print(f"Total Insurance Premiun:      {fv.FDollar2(TotInsPrem):>10s}")
    print(f"HST:                             {fv.FDollar2(HSTCal)}")
    print(f"                               ---------")
    print(f"Total Costs:                  {fv.FDollar2(TotalCost)}")

    print(f"Monthly Payment:                {fv.FDollar2(MonthlyPayment)}")
    print(f"First Payment Date:           {FirstPaymentDate}")
    print(f"----------------------------------------")

    print(f"    ONE STOP - Insuring the world!")
    
    print()

    # list of previous claims

    Previousclaims = ["2023-01-01    $10,000.00", 
                   "2023-06-06    $13,000.00",
                   "2023-11-16    $11,000.00",
                 ]

     # Using a loop to print value
    claimNum = 1
    print()
    for claim in Previousclaims:
        print(f"{claimNum}.    {claim}")
        claimNum += 1
    
    
     


    Continue = input(" Do you want to enter  another customer insurance policy information(Y/N)?").upper()
    if Continue == "N":
        break


    


    


    
            











    










